/**
 * class MyStack: A stack class implemented by using ArrayList
 * All stack elements are stored in an ArrayList. The top element
 * has index top
 * 
 * @author Dustin Riley
 * @version 09/27/2022
 */
import java.util.ArrayList;

public class MyStack<E> extends CSCI251ProjectTwo
{
    private ArrayList<E> list; // used to store elements in stack
    private int top; // the index of top element
    
    /**
     * constructor construct an empty stack
     */
    public MyStack()
    {
        list = new ArrayList<E>(); //declare new arrayList<E>
        top = -1; // set top to empty value
    }
    
    /**
     * push push a given element on the top of the stack
     */
    public void push(E item)
    {
        top++; // set top to new top element index
        list.add(item); // add new item to arraylist
    }
    
    /**
     * isEmpty return true if the stack is empty; false otherwise
     * @return true if the stack is empty; false otherwise
     */
    public boolean isEmpty()
    {
        return (top == -1); // returns whether or not arraylist is empty by checking if top is at empty value
    }
    
    /**
     * peek Return the top element
     */
    public E peek()
    {
       return list.get(top); // gets the value at top index of arraylist
    }
    
    /**
     * pop Remove the top element from the stack. If the stack is empty,nothing happen
     */
    public void pop()
    {
       list.remove(top); // removes the top index of arraylist
       top--; // sets top to the new top index of arraylist
    }
    
    /**
     * size return the size of the stack
     * @return number of elements in stack
     */
    public int size()
    {
        return list.size(); // returns the size of the arraylist
    }
}