/**
 * CSCI463ProjectTwo: Use MyStack and MyQueue to write a project that check if a sentence is palindrom
 * 
 * @author Dustin Riley
 * @version 9/27/2022
 */
import java.util.Scanner;

public class CSCI251ProjectTwo
{
    public static void main(String [] args)
    {
        Scanner input = new Scanner(System.in);
        String sentence;
        String again;
        do{
            System.out.println("Enter a sentence, I will tell you if it is a palindrome: ");
            sentence = input.nextLine();
            if(isPalindrome(sentence))
                System.out.println("\"" + sentence + "\" is a palindrome!");
            else
                System.out.println("\"" + sentence + "\" is not a palindrome!");
            System.out.println("Do you want another test (\"YES\" or \"NO\"): ");
            again = input.nextLine();
        }while(again.equalsIgnoreCase("YES"));
        input.close();
    }
    
    /**
     * isPalindrom returns true if the given String is a palindrom
     * @
     */
    public static boolean isPalindrome(String sentence)
    {
        // declare a MyStack s
        MyStack s = new MyStack();
        // declare a MyQueue q
        MyQueue q = new MyQueue();

        for(int i = 0; i < sentence.length(); i++)
        {
            if(Character.isLetter(sentence.charAt(i))) {// if ith character in sentence is a letter
                char x = sentence.toUpperCase().charAt(i);
                s.push(x);// convert to upper case and push it into s and q
                q.push(x);
            }
        }
        while(!s.isEmpty()){
            if (q.peek() != s.peek()) {// if the front of the queue not match the top of stack
                return false;// return false
            }
            s.pop();
            q.pop();// pop out top of the stack and front of the queue
        }
        return true;
    }
   
}