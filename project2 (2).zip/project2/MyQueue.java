/**
 * class MyQueue implemented using ArrayList. The index 0 element is the front of the queue
 * The last element of the queue has index tail
 * @author Dustin Riley
 * @version 09/27/2022
 */
import java.util.ArrayList;

public class MyQueue<E>
{
    private ArrayList<E> list; // hold the elements in queue
    private int tail; // index of the last element in queue
    /**
     * constructor construct an empty queue
     */
    public MyQueue()
    {
        list = new ArrayList<E>(); // creates new arrayList<E> called list
        tail = 0; // sets tail index to empty value for arraylist
    }
    
    /**
     * isEmpty return true if the queue is empty; false otherwise
     * @return true if the queue is empty; false otherwise
     */
    public boolean isEmpty()
    {
        return (tail == 0); // returns whether or not the tail index is at the empty value for arraylist
    }
    
    /**
     * size return the size of the queue
     * @return the number of elements in queue
     */
    public int size()
    {
        return list.size(); // returns the size of the arraylist
    }
    
    /**
     * peek return the front element of the queue
     * @return the front element of the queue. If the queue is empty, return null
     */
    public E peek()
    {
        return list.get(0); // returns the value of the first index of arraylist
    }
    
    /**
     * pop remove the front element of the queue
     */
    public void pop()
    {
        list.remove(0); // removes the first index of arraylist
        tail--; // set tail to the new ending index of arraylist
    }
    
    /**
     * push push a new element to the queue
     */
    public void push(E item)
    {
        list.add(item); // add new item to arraylist
        tail++; // set tail to the new ending index of arraylist
    }
}