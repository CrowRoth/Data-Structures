/**
 * BinearySearchTree. Represent a binary search tree
 * The student cannot change the public interface
 * 
 * @author Dustin Riley
 * @version 11/08/2022
 */
public class BinarySearchTree<E extends Comparable<E>>
{
    TreeNode<E> root; // the root of the tree
    TreeNode<E> cur; // the current node in the tree
    TreeNode<E> suc; // successor node
    int count = 0; // number of nodes in the tree
    
    /**
     * constructor create a empty binary search tree by setting root to be null
     */
    public BinarySearchTree(){
        root = null;
    }
    
    /**
     * search the given data in this binary search tree
     * If the data is found, return a reference to the tree node
     * othewise, return null
     * @param data The target to search
     * @return a TreeNode reference to the node that contains the data
     *         if no node contains data, return null
     */
    public TreeNode<E> search(E data){
        cur = this.root; // start at root
        while(cur != null) {
            if(data.compareTo(cur.getData()) == 0) { //checks if current nodes data matches key
                return cur;
            }
            else if(data.compareTo(cur.getData()) < 0) { //if key is < current nodes data
                cur = cur.getLeft();
            }
            else {
                cur = cur.getRight();
            }
        }
        return null;
    }
    
    /**
     * insert given node to this binary search tree. If this tree 
     * was empty, the given node becomes the root of this tree.
     * @param newNode the given node to be inserted
     */
    public void insert(TreeNode<E> newNode){
        if(this.isEmpty()) { // if tree empty
            root = newNode;
        }
        else {
            cur = root; //start at root
            while(cur != null) {
                if(newNode.getData().compareTo(cur.getData()) < 0) { // if newNode data is < current nodes data
                    if(cur.getLeft() == null) { //if current nodes left is empty
                        cur.setLeft(newNode); //set new node as current nodes left
                        cur.getLeft().setParent(cur); //set new nodes parent neccesary for correct removal
                        cur = null;
                    }
                    else {
                        cur = cur.getLeft(); //go to left node
                    }
                }
                else { // if newNode data is >= current nodes data
                    if(cur.getRight() == null) { //if current nodes right is empty
                        cur.setRight(newNode);
                        cur.getRight().setParent(cur);
                        cur = null;
                    }
                    else {
                        cur = cur.getRight(); //go to right node
                    }
                }
            }
        }
        count++; //new node inserted count + 1
    }
    
    /**
     * insert given data to this binary search tree. If this tree 
     * was empty, the given node becomes the root of this tree.
     * @param data the given data to be inserted
     */
    public void insert(E data){
        TreeNode<E> newNode = new TreeNode<>(); //create new node
        newNode.setData(data); //set parameter data to new nodes data
        insert(newNode); //go run the insert() with node parameter
    }
    
    /**
     * remove the given data from this binary search tree and return
     * true. If the data is not in the tree, return false
     */
    public boolean remove(E data){
        cur = search(data); // find the node with data
        if(cur == null) { // if node not found
            return false;
        }
        else {
            count--; //node is removed count - 1
            if(cur.isLeaf()) { //remove leaf
                if(cur.isRoot()) { //root node
                    root = null;
                }
                if(cur.isLeftChild()) { //left child node
                    cur.getParent().setLeft(null);
                }
                else { //right child node
                    cur.getParent().setRight(null);
                }
            }
            else if(cur.getRight() == null) { //Remove node with only left child
                if(cur.isRoot()) { //root node
                    root = cur.getLeft();
                }
                if(cur.isLeftChild()) {
                    cur.getParent().setLeft(cur.getLeft());
                }
                else {
                    cur.getParent().setRight(cur.getLeft());
                }
            }
            else if(cur.getLeft() == null) { //Remove node with only right child
                if(cur.isRoot()) { //root node
                    root = null;
                }
                if(cur.isLeftChild()) {
                    cur.getParent().setLeft(cur.getRight());
                }
                else {
                    cur.getParent().setRight(cur.getRight());
                }
            }
            else { //Remove node with two children
                suc = cur.getRight(); //get right child
                while(suc.getLeft() != null) { //get left most child of right child
                    suc = suc.getLeft();
                }
                E sucData = suc.getData(); //copy its data
                suc = cur; //use suc to save current node position
                remove(sucData); //rerun remove(which changed cur) to remove left most child of right child
                suc.setData(sucData); // copy its data into the initial node marked for removal
            }
            return true;
        }
    }
    
    /**
     * return a string representation of the tree
     * @return a String representation of the tree
     */
    public String toString(){
        return "(" + nodeTravesal(root) + ")";
    }
    
    /**
     * return true if the tree is empty. False otherwise
     * @return true if the tree is empty; false othewise
     */
    public boolean isEmpty(){
        return root == null;
    }
    
    /**
     * return the height of the tree. Notice the height is defined as
     * the length of the longest path from nodes to root
     * @return the height of the tree
     */
    public int height(){
        cur = root; //start at root
        return getHeight(cur);
    }

    private int getHeight(TreeNode<E> node) {
        if(node == null) { //if recursively reach a null node return -1 
            return -1;
        }
        int leftHeight = getHeight(node.getLeft()); //recursively get heights of left side of tree
        int rightHeight = getHeight(node.getRight()); //recursively get heights of right side of tree
        return 1 + Math.max(leftHeight, rightHeight); //find maximum height of left and right heights + 1
    }
    
    /**
     * return the number of nodes in the tree
     * @return the number of nodes in this tree
     */
    public int size(){
        return count;
    }

    

    private String nodeTravesal(TreeNode<E> treeNode)
    {
        if(treeNode == null) { //mark null nodes as -
            return "-";
        }
        return treeNode.getData().toString() // return current nodes data as string
               + "(" + nodeTravesal(treeNode.getLeft()) //go to left node
               +", " + nodeTravesal(treeNode.getRight()) + ")"; // go to right node
    }
    

}
