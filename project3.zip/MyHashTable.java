
/**
 * class MyHashTable. A simple HashTable. Handle collision by chain`
 * 
 * @author Hongbiao Zeng
 * @version Nov 27, 2015
 */
import java.util.ArrayList;

public class MyHashTable<K extends Comparable<K>, V>
{
    private ArrayList<MyHashEntry<K, V>> table;
    private int count; // how many elements in table
    
    /**
     * Constructor. Constructor an empty MyHashTable with given number of Buckets
     * @param tableSize The number of Buckets of the table
     */
    public MyHashTable(int tableSize){
        this.table = new ArrayList<>(tableSize); //create new arraylist with size from parameter
        for(int i = 0;i < tableSize;i++) {
            this.table.add(null); //create buckets in arraylist and set to null
        }
        this.count = 0;
    }
    
    /**
     * constructor. Construct an empty MyHashTable with capacity 10 buckets
     */
    public MyHashTable(){
        this(10);
    }
    
    /**
     * get the number of elements in the table
     * @return the number of elements in the table
     */
    public int size(){
        return this.count;
    }
    
    /**
     * clear the table
     */
    public void clear(){
        for(int i = 0;i < this.table.size();i++) {
            this.table.set(i, null);
        }
    }
    
    /**
     * get the value with given key.
     * @param key The given key
     * @return the value that have the key matches the given key. If no such a value, return null
     */
    public V get(K key){
        int x = key.hashCode() % this.table.size(); //modulus of key used for finding bucket in arraylist
        if(this.table.get(x) == null) { //if bucket x in arraylist is empty (doesnt have a MyHashEntry node) then return null
            return null; //item not found in this bucket
        }
        MyHashEntry<K, V> node = this.table.get(x); //get headnode at arraylist bucket x
        while(node != null && node.getKey().compareTo(key) != 0) { //while not at the end of the list, and matching key not found
            node = node.getNext(); //get next node in bucket
        }
        if (node == null) { //if node is null then we're at the end of the list in this bucket
            return null; //item not found in this bucket
        }
        return (V)node.getValue(); //item found return value
    }
    
    /**
     * insert (key, value) pair into the table
     * @param key The key of the pair
     * @param value The value of the pair
     */
    public void insert(K key, V value){
        int x = key.hashCode() % this.table.size(); //modulus of key used for finding bucket in arraylist
        if(this.table.get(x) == null) { //if bucket x in arraylist is empty (doesnt have a MyHashEntry node)
            MyHashEntry<K, V> node = new MyHashEntry(key, value); //create new node with parameter key and value
            this.table.set(x, node); //insert node in arraylist bucket x
            this.count++; //count + 1 new entry
            return; //exit insert()
        } 
        MyHashEntry<K, V> node = this.table.get(x); //get headnode at arraylist bucket x
        while(node.getNext() != null && node.getKey().compareTo(key) != 0) { //while not at the end of the list and matching key not found
            node = node.getNext(); //get next node in bucket
        }
        if (node.getKey().compareTo(key) == 0) { //if parameter key matches key in node
            node.setValue(value); //set nodes value to parameter value
        } //this is to edit the value of a previously entered node(key,value) with the same key
        else {
            MyHashEntry<K, V> newnode = new MyHashEntry(key, value); //create newnode with parameter key and value
            node.setNext(newnode); //insert newnode as nextnode in list at bucket x
        }
        this.count++; //count + 1 new entry
    }
    
    /**
     * remove the value with given key from the table
     * @param key The given key
     * @return the value whose key matches the given key. If no such value, null is returned
     */
    public V remove(K key){
        int x = key.hashCode() % this.table.size(); //remainder of key used for finding bucket in arraylist
        if(this.table.get(x) == null) { //if bucket x in arraylist is empty (doesnt have a MyHashEntry node)
            return null; //item not found in this bucket
        }
        MyHashEntry<K, V> node = this.table.get(x); //get headnode at arraylist bucket x
        if(node.getKey().compareTo(key) == 0) { //if matching key found
            V y = (V)node.getValue(); //get headnode value
            this.table.set(x, node.getNext()); //erase headnode and set next node in its place (works even if nextnode is node(key, value) or null(end of list))
            this.count--; //count - 1 entry
            return y; //return old headnodes value
        }
        while(node.getNext() != null && node.getNext().getKey().compareTo(key) != 0) { //while not at the end of the list and parameter key doesn't match nextnodes key
            node = node.getNext(); //get next node in bucket
        }
        if(node.getNext() == null) { //if the node after current node is null we're at the end of the list in this bucket
            return null; //item not found in bucket
        }
        MyHashEntry<K, V> nextnode = node.getNext(); //get node after current node
        node.setNext(nextnode.getNext()); //erase current node and set it as the node after nextnode
        this.count--; //count - 1 entry
        return (V)nextnode.getValue(); //return nextnodes value
    }
    
    /**
     * check if the table is empty,i.e. no node
     * @return true if the table holds no elements; false otherwise
     */
    public boolean isEmpty(){
        return this.count == 0;
    }
    
    /**
     * return a String representation of the table
     * @return a String representation of the table
     */
    public String toString(){
        String str = ""; //new string
        for(int i = 0;i < this.table.size();i++) { //go through all buckets in array list
            str += "\nbucket " + i + ": "; //add on a new line "bucket i: " to string
            MyHashEntry node = this.table.get(i); //get headnode at bucket i
            while (node != null) { //while currentnode at bucket i is not empty
                str += node.getValue(); //add "node value"
                if(node.getNext() != null) { //if next node is not null
                    str += ", "; //add comma to string
                }
                node = node.getNext(); //get next node
            }
        };
        return str;
    }
}